﻿// MIS 3013 001
// Jan 29, 2024
// Andrea Hernandez
// 113552217

// string: complex datatype
string str1;
st21 = "This is a string";// "" is the syntax to define a string

Console.WriteLine(str1);

//console.ReadLine

Console.ReadLine();// Readline is a function
// Readline() is a function call
// the final product is a string

Console.WriteLine("The user input is ");
Console.WriteLine(str2);

//
string str3;
str3 = "20";// str3 is a string, not an integer

int age1;
Convert.ToInt32(str3);//

Console.Writeline(age1 + 2);

//
string str4;
str4 = console.readline();
int age2;
age2 = Convert.ToInt32(str4);
Console.WriteLine(age2 + 10);

